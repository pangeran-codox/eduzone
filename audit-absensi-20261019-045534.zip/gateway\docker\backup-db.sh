#!/bin/sh
# backup-db.sh — backup harian eduzone_absensi
#
# Cara pakai (jalankan dari host, bukan dari dalam container):
#   docker exec postgres sh /backup-db.sh
#
# Atau copy dulu ke container postgres:
#   docker cp docker/backup-db.sh postgres:/backup-db.sh
#   docker exec postgres chmod +x /backup-db.sh
#
# Untuk jadwal otomatis, tambahkan ke crontab host (bukan container):
#   0 2 * * * docker exec postgres sh /backup-db.sh >> /var/log/absensi-backup.log 2>&1

set -e

BACKUP_DIR="${BACKUP_DIR:-/var/backups/absensi}"
DB_NAME="eduzone_absensi"
DB_USER="${POSTGRES_USER:-laravel}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/${DB_NAME}_${TIMESTAMP}.sql.gz"

# Buat folder backup kalau belum ada
mkdir -p "$BACKUP_DIR"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Mulai backup $DB_NAME..."

pg_dump -U "$DB_USER" "$DB_NAME" | gzip > "$BACKUP_FILE"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Backup selesai: $BACKUP_FILE ($(du -h "$BACKUP_FILE" | cut -f1))"

# Hapus backup lebih dari 30 hari
find "$BACKUP_DIR" -name "${DB_NAME}_*.sql.gz" -mtime +30 -delete
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cleanup backup > 30 hari selesai"
