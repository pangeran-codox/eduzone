# Audit Integrasi Laravel ↔ Absensi Gateway

Dokumen ini adalah checklist lengkap untuk memastikan sisi Laravel
sudah menyediakan semua yang dibutuhkan gateway. Baca ini dari atas
ke bawah — urutannya penting.

---

## Ringkasan: Apa yang Laravel Harus Sediakan

| # | Apa | Arah | Dipakai Untuk |
|---|---|---|---|
| 1 | `GET /api/internal/sync/schools` | Laravel → Gateway | Cache `schools_ref` (geofence, terlambat) |
| 2 | `GET /api/internal/sync/people` | Laravel → Gateway | Cache `people_ref` (validasi, nama, foto) |
| 3 | `GET /api/internal/sync/schedules` | Laravel → Gateway | Cache `schedules_ref` (jam pelajaran) |
| 4 | `GET <photo_url>` (URL bebas) | Laravel → Gateway | Proxy foto profil di `/api/v1/media/photo/{person_id}` |
| 5 | JWT yang diterbitkan guru | Laravel → Gateway | Auth endpoint check-in guru |

Gateway **tidak pernah memanggil balik Laravel** selain 3 endpoint sync
dan fetch foto. Tidak ada webhook, tidak ada push — Laravel pasif,
gateway yang pull.

---

## 1. Autentikasi Sync (X-Sync-Token)

### Yang diperiksa

Gateway mengirim header ini di **semua** request sync:
```
X-Sync-Token: <nilai LARAVEL_SYNC_TOKEN di .env gateway>
```

### Yang harus ada di Laravel

- [ ] **Env var** `ABSENSI_SYNC_TOKEN` di `.env` Laravel, isinya **sama persis**
  dengan `LARAVEL_SYNC_TOKEN` di `.env` gateway.
- [ ] **Middleware** yang membaca header `X-Sync-Token` dan membandingkan
  dengan `ABSENSI_SYNC_TOKEN` menggunakan `hash_equals()` (bukan `===`
  — `hash_equals` tahan timing attack).
- [ ] Kalau tidak cocok → balas **401**, body bebas (gateway cuma lihat status code).
- [ ] Middleware ini **hanya** dipasang di route `/api/internal/sync/*`,
  BUKAN di route guru/login/publik.

### Tes cepat

```bash
# Harus 401
curl -i http://eduzone_app/api/internal/sync/schools

# Harus 200 (atau array kosong [] — tetap 200)
curl -i -H "X-Sync-Token: <token>" http://eduzone_app/api/internal/sync/schools?page=1&per_page=500
```

---

## 2. Endpoint `GET /api/internal/sync/schools`

### Parameter query yang dikirim gateway

| Param | Contoh | Keterangan |
|---|---|---|
| `page` | `1` | Mulai dari 1 |
| `per_page` | `500` | Selalu 500 |
| `updated_since` | `2026-09-01T00:00:00Z` | RFC3339. **Tidak ada** = sync pertama, kembalikan SEMUA |

### Format response yang diharapkan gateway

```json
[
  {
    "school_id": "11111111-1111-1111-1111-111111111111",
    "name": "SMA Negeri 1 Contoh",
    "latitude": -7.7956,
    "longitude": 113.7108,
    "geofence_radius_meters": 150,
    "late_cutoff_time": "07:15:00",
    "is_active": true,
    "updated_at": "2026-09-20T08:00:00+07:00"
  }
]
```

### Checklist field per field

| Field | Tipe Go | Nullable | Aturan |
|---|---|---|---|
| `school_id` | `string` | ❌ | UUID, sama dengan `schools.id` di DB utama |
| `name` | `string` | ❌ | Nama sekolah |
| `latitude` | `float64` | ❌ | Titik pusat sekolah — **bukan** angka nol kalau belum diisi, karena 0,0 adalah koordinat valid (Teluk Guinea). Kalau memang belum ada koordinat, jangan kirim record itu sama sekali atau tandai `is_active: false` |
| `longitude` | `float64` | ❌ | Sama seperti latitude |
| `geofence_radius_meters` | `int` | ❌ | Integer, default wajar 150. Jangan kirim 0 (semua guru langsung flagged) |
| `late_cutoff_time` | `*string` | ✅ | Format **`"HH:MM:SS"`** atau **`null`**. Kalau sekolah belum atur jam masuk → kirim `null`. Gateway tidak akan label siapapun "Terlambat" sampai diisi. **Jangan kirim string kosong `""`** — tidak ada yang akan mem-parse itu jadi waktu valid |
| `is_active` | `bool` | ❌ | `true`/`false` — bukan integer 0/1 |
| `updated_at` | `time.Time` (RFC3339) | ❌ | Wajib ada, dipakai sebagai watermark. Harus ikut berubah kalau ada field apapun yang di-update |

### Hal yang sering salah

- [ ] `late_cutoff_time` dikirim sebagai `""` (string kosong) → gateway gagal parse, record dilewati
- [ ] `updated_at` tidak di-touch saat `is_active` berubah → record nonaktif tidak pernah ter-sync
- [ ] Response dibungkus `{"data": [...]}` → gateway gagal decode, error `cannot unmarshal object into Go value of type []sync.SchoolRecord`
- [ ] `latitude`/`longitude` dikirim sebagai string `"−7.7956"` bukan angka → gagal decode

---

## 3. Endpoint `GET /api/internal/sync/people`

### Format response yang diharapkan gateway

```json
[
  {
    "person_id": "22222222-2222-2222-2222-222222222222",
    "school_id": "11111111-1111-1111-1111-111111111111",
    "person_type": "student",
    "full_name": "Andi Saputra",
    "photo_url": "http://eduzone_app/storage/photos/andi.jpg",
    "class_id": "33333333-3333-3333-3333-333333333333",
    "grade": "10",
    "is_active": true,
    "updated_at": "2026-09-20T08:00:00+07:00"
  },
  {
    "person_id": "44444444-4444-4444-4444-444444444444",
    "school_id": "11111111-1111-1111-1111-111111111111",
    "person_type": "teacher",
    "full_name": "Budi Santoso",
    "photo_url": null,
    "class_id": null,
    "grade": null,
    "is_active": true,
    "updated_at": "2026-09-19T14:00:00+07:00"
  }
]
```

### Checklist field per field

| Field | Tipe Go | Nullable | Aturan |
|---|---|---|---|
| `person_id` | `string` | ❌ | UUID. Untuk `student` = `students.id`, untuk `teacher` = `teachers.id`, dst. Boleh sama nilainya antar type karena gateway pakai kombinasi `(person_id, person_type)` sebagai primary key |
| `school_id` | `string` | ❌ | Harus sudah ada di `schools_ref`. Kalau sekolahnya belum ter-sync, record ini akan gagal FK constraint dan di-skip (dicatat di log gateway) |
| `person_type` | `string` | ❌ | **Harus** salah satu dari: `student`, `teacher`, `staff` (huruf kecil semua). Nilai lain → gagal DB constraint → record dilewati |
| `full_name` | `string` | ❌ | Tidak boleh kosong |
| `photo_url` | `*string` | ✅ | URL lengkap yang bisa diakses dari dalam jaringan Docker gateway (lihat bagian 4). Kalau tidak ada foto → kirim `null` (bukan `""`) |
| `class_id` | `*string` | ✅ | UUID atau `null`. Wajib ada untuk `student`, boleh null untuk `teacher`/`staff` |
| `grade` | `*string` | ✅ | Bebas, mis. `"10"`, `"XI IPA 2"`. Boleh `null` |
| `is_active` | `bool` | ❌ | |
| `updated_at` | RFC3339 | ❌ | |

### Hal yang sering salah

- [ ] `person_type` dikirim `"Student"` (kapital) atau `"guru"` (bahasa Indonesia) → gagal CHECK constraint di DB
- [ ] `photo_url` URL pakai hostname NPM/publik (`https://eduzone.sch.id/...`) — gateway fetch dari **dalam Docker** dan NPM tidak resolve dari sana. Harus pakai hostname container internal, mis. `http://eduzone_app/storage/...`
- [ ] Record guru dikirim dengan `class_id` diisi (`not null`) tapi UUID-nya tidak valid → gagal FK kalau ada referensi, atau tersimpan tapi tidak berguna

---

## 4. Endpoint `GET /api/internal/sync/schedules`

### Format response yang diharapkan gateway

```json
[
  {
    "schedule_id": "55555555-5555-5555-5555-555555555555",
    "school_id": "11111111-1111-1111-1111-111111111111",
    "class_id": "33333333-3333-3333-3333-333333333333",
    "subject_name": "Matematika",
    "teacher_id": "44444444-4444-4444-4444-444444444444",
    "day_of_week": 1,
    "start_time": "07:00:00",
    "end_time": "08:30:00",
    "is_active": true,
    "updated_at": "2026-09-15T09:00:00+07:00"
  }
]
```

### Checklist field per field

| Field | Tipe Go | Nullable | Aturan |
|---|---|---|---|
| `schedule_id` | `string` | ❌ | UUID |
| `school_id` | `string` | ❌ | Harus sudah ada di `schools_ref` |
| `class_id` | `string` | ❌ | UUID kelas |
| `subject_name` | `string` | ❌ | Nama mapel |
| `teacher_id` | `string` | ❌ | UUID guru — harus sudah ada di `people_ref` sebagai `person_type = 'teacher'` kalau ingin resolusi jadwal aktif berfungsi |
| `day_of_week` | `int` | ❌ | **`1 = Senin`, ..., `7 = Minggu`** (ISO 8601). **Bukan** `0 = Minggu` ala PHP `date('w')`. Kalau Laravel pakai `Carbon::dayOfWeek` (0=Minggu), perlu konversi: `$day = $schedule->day_of_week == 0 ? 7 : $schedule->day_of_week` |
| `start_time` | `string` | ❌ | Format `"HH:MM:SS"`, mis. `"07:00:00"`. **Bukan** timestamp penuh. Bukan `"07:00"` tanpa detik (Go akan gagal parse) |
| `end_time` | `string` | ❌ | Sama seperti `start_time` |
| `is_active` | `bool` | ❌ | |
| `updated_at` | RFC3339 | ❌ | |

### Hal yang sering salah

- [ ] `day_of_week` pakai konvensi PHP `0=Minggu` → jadwal Senin dikirim sebagai `1`, Minggu sebagai `0`. Gateway tidak bisa menemukan jadwal Minggu sama sekali karena kolom di-constraint `BETWEEN 1 AND 7`
- [ ] `start_time`/`end_time` dikirim sebagai `"07:00"` (tanpa detik) → Go `time.Parse("15:04:05", ...)` gagal
- [ ] `start_time`/`end_time` dikirim sebagai timestamp penuh `"2026-09-20T07:00:00+07:00"` → juga gagal parse

---

## 5. Perilaku Paginasi (berlaku untuk semua 3 endpoint)

Gateway terus minta halaman berikutnya **sampai jumlah record yang
dikembalikan < 500**. Ini sinyal "halaman terakhir".

### Yang harus diperhatikan

- [ ] Kalau total data 1000, halaman 1 harus mengembalikan tepat 500 record,
  halaman 2 mengembalikan sisa 500 → gateway pikir masih ada halaman 3,
  minta halaman 3 → Laravel balas `[]` → gateway berhenti.
  Ini **bukan bug** — hanya 1 request ekstra untuk halaman kosong.
- [ ] **Urutan harus konsisten**: query harus pakai `ORDER BY updated_at ASC`
  (bukan tanpa `ORDER BY`). Kalau tidak ada ordering, saat data berubah
  di tengah proses paginasi (halaman 2 dari 3), baris bisa terlewat atau
  muncul dobel. Tidak fatal (gateway UPSERT jadi tidak ada duplikat), tapi
  watermark bisa tidak akurat.
- [ ] Kalau tidak ada data sama sekali → balas `[]` (array kosong), **bukan**
  body kosong, **bukan** `null`, **bukan** `{"data": []}`.

---

## 6. Format `updated_at` — Aturan Umum

Gateway men-decode semua `updated_at` sebagai `time.Time` dengan
`json.Unmarshal` standar Go, yang menerima **RFC3339** (`time.RFC3339`).

Format yang diterima:
- `"2026-09-20T08:00:00+07:00"` ✅
- `"2026-09-20T01:00:00Z"` ✅ (UTC)
- `"2026-09-20T08:00:00.000000Z"` ✅ (dengan sub-detik, juga oke)

Format yang **tidak diterima**:
- `"2026-09-20 08:00:00"` ❌ (tanpa T, tanpa timezone — format MySQL default)
- `"20/09/2026 08:00"` ❌
- Unix timestamp integer `1758355200` ❌

Kalau Laravel menggunakan `toDateTimeString()` → hasilnya `"2026-09-20 08:00:00"` yang **gagal**. Harus pakai `toRfc3339String()` atau `toIso8601String()`.

---

## 7. Foto Profil (`photo_url`)

`photo_url` yang ada di `people_ref.photo_url` dipakai gateway di
`GET /api/v1/media/photo/{person_id}` untuk mengambil foto **server-to-server**,
lalu di-cache dan di-serve ke kiosk/browser.

### Checklist

- [ ] URL harus bisa diakses dari **dalam container gateway** (bukan dari
  browser publik). Gunakan hostname service Docker, mis.
  `http://eduzone_app/storage/photos/andi.jpg` — **bukan**
  `https://cdn.eduzone.id/photos/andi.jpg` yang mungkin tidak reachable dari jaringan Docker.
- [ ] Endpoint foto harus balas **200** dengan body gambar dan header
  `Content-Type` yang benar (`image/jpeg`, `image/png`, dll).
- [ ] Ukuran foto maksimal **10 MB** (batas gateway). Foto profil wajar
  jauh di bawah ini — tapi perlu diperhatikan kalau foto di-resize di sisi Laravel.
- [ ] Kalau foto tidak ada → balas **404**. Gateway akan fallback ke avatar
  inisial SVG secara otomatis. Jangan balas 200 dengan body HTML error page.
- [ ] Timeout: gateway membatasi fetch foto ke **10 detik**. Kalau Laravel
  butuh lebih dari itu untuk melayani 1 foto, ada masalah di sisi storage.

---

## 8. JWT untuk Check-in Guru

Gateway memverifikasi JWT **secara lokal** (tidak memanggil balik
Laravel) menggunakan `JWT_SECRET` (HS256). Ini berarti:

- [ ] Token JWT yang diterbitkan Laravel **harus** menggunakan algoritma
  **HS256** (HMAC-SHA256) dengan secret yang **sama persis** dengan
  `JWT_SECRET` di `.env` gateway.
- [ ] Payload token harus mengandung field berikut (nama field harus sama persis):

  ```json
  {
    "user_id": "44444444-4444-4444-4444-444444444444",
    "school_id": "11111111-1111-1111-1111-111111111111",
    "role": "teacher",
    "exp": 1758441600
  }
  ```

  | Field | Tipe | Keterangan |
  |---|---|---|
  | `user_id` | string | UUID guru, harus ada di `people_ref` sebagai `person_type = 'teacher'` |
  | `school_id` | string | UUID sekolah, harus ada di `schools_ref` |
  | `role` | string | Dipakai `RequireRole("admin")` untuk enrollment. Guru biasa isi `"teacher"`, admin isi `"admin"` |
  | `exp` | Unix timestamp | Standard JWT expiry — gateway otomatis tolak token kedaluwarsa |

- [ ] Kalau Laravel pakai `sub` untuk user ID (bukan `user_id`) → token
  gagal dipetakan ke `claims.UserID` dan check-in guru selalu dapat
  `""` sebagai `userID` → event absensi tersimpan tanpa `person_id`.
- [ ] **Jangan** pakai RS256/EdDSA tanpa mengubah kode Go — saat ini
  gateway hanya menerima HS256. Kalau mau upgrade ke RS256, kode di
  `middleware/auth.go` perlu diubah.

### Tes cepat JWT

```bash
# Generate token di Laravel, lalu:
curl -i -X POST http://absensi-gateway:8080/api/v1/checkin/teacher \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"event_type":"check_in","latitude":-7.7956,"longitude":113.7108,"accuracy_meters":10}'
```

Kalau dapat **401 `invalid_token`** → secret tidak cocok atau algoritma salah.  
Kalau dapat **500 `internal_error` "Gagal memuat data sekolah"** → JWT valid,
tapi `school_id` di token belum ada di `schools_ref`. Sync schools dulu.

---

## 9. Jaringan Sekolah (`school_networks`)

Tabel ini **tidak di-sync otomatis dari Laravel** — diisi manual atau
lewat tool admin terpisah. Tapi perlu diaudit juga.

### Apa yang perlu dicek

- [ ] Setiap sekolah yang guru-nya mau bisa check-in via web/PWA **harus**
  punya minimal 1 baris di `school_networks` dengan IP publik sekolah
  yang benar dan `requires_local_verifier = false`.
- [ ] Kalau tidak ada baris sama sekali → check-in guru selalu dapat
  `anomaly_reason: "ip_not_whitelisted"` → status `accepted_with_flag`.
  Absensi tetap masuk tapi di-flag — perlu tindakan admin.
- [ ] IP di kolom `ip_or_hostname` harus **IP publik** yang benar-benar
  terlihat gateway, bukan IP LAN internal sekolah. Bisa dicek dari log
  gateway: `clientIP` yang terlihat saat guru check-in.

---

## 10. Urutan Pengisian Data yang Benar

Kalau melakukan setup awal (bukan sync otomatis), urutan ini **wajib**
diikuti karena ada foreign key constraint di DB gateway:

```
1. schools_ref      ← harus ada dulu
       ↓
2. people_ref       ← butuh school_id valid
       ↓
3. schedules_ref    ← butuh school_id valid
       ↓
4. devices          ← butuh school_id valid
       ↓
5. credentials      ← butuh (person_id, person_type) valid di people_ref
```

Kalau sync otomatis diaktifkan, gateway sudah mengurus urutan ini
sendiri (schools dulu → people → schedules).

---

## 11. Checklist Ringkas untuk Tim Laravel

Copy-paste ini ke task tracker:

```
[ ] Buat env ABSENSI_SYNC_TOKEN, samain nilainya dengan LARAVEL_SYNC_TOKEN di gateway
[ ] Buat middleware VerifySyncToken dengan hash_equals()
[ ] Pasang middleware ke route /api/internal/sync/*
[ ] Buat GET /api/internal/sync/schools
    [ ] Support ?updated_since=<RFC3339>, ?page=<int>, ?per_page=<int>
    [ ] Response array JSON polos (bukan dibungkus "data")
    [ ] updated_at pakai toRfc3339String()
    [ ] late_cutoff_time format "HH:MM:SS" atau null (bukan "")
    [ ] ORDER BY updated_at ASC
[ ] Buat GET /api/internal/sync/people
    [ ] person_type harus "student" / "teacher" / "staff" (lowercase)
    [ ] photo_url pakai URL internal Docker, bukan URL publik
    [ ] photo_url null kalau tidak ada (bukan "")
    [ ] ORDER BY updated_at ASC
[ ] Buat GET /api/internal/sync/schedules
    [ ] day_of_week: 1=Senin s.d. 7=Minggu (bukan 0=Minggu)
    [ ] start_time/end_time format "HH:MM:SS" (dengan detik)
    [ ] ORDER BY updated_at ASC
[ ] Pastikan foto bisa diakses dari dalam Docker (bukan hanya dari luar)
[ ] Pastikan JWT diterbitkan dengan HS256 + secret yang sama
[ ] Pastikan payload JWT punya field: user_id, school_id, role, exp
[ ] Isi school_networks dengan IP publik tiap sekolah (manual)
```

---

## 12. Cara Verifikasi End-to-End

Setelah semua selesai, verifikasi dalam urutan ini:

1. **Cek koneksi sync schools:**
   ```bash
   curl -H "X-Sync-Token: <token>" \
     "http://eduzone_app/api/internal/sync/schools?page=1&per_page=500"
   ```
   Harus: status 200, body `[{...}]` atau `[]`.

2. **Aktifkan sync di gateway**, pantau log:
   ```bash
   docker logs -f absensi-gateway
   # Cari: "sync schools: sukses, N record diproses"
   # Cari: "sync people: sukses, N record diproses"
   # Cari: "sync schedules: sukses, N record diproses"
   ```
   Kalau ada `DILEWATI (gagal disimpan)` → ada data yang bermasalah,
   baca pesan error-nya (biasanya FK atau CHECK constraint violation).

3. **Tes check-in device** dengan RFID/QR yang sudah di-enroll.

4. **Tes check-in guru:**
   ```bash
   # Generate JWT dari Laravel, lalu kirim dengan koordinat sekolah
   curl -X POST http://absensi-gateway:8080/api/v1/checkin/teacher \
     -H "Authorization: Bearer <jwt>" \
     -H "Content-Type: application/json" \
     -d '{"event_type":"check_in","latitude":-7.7956,"longitude":113.7108,"accuracy_meters":10}'
   ```
   Response `accepted` (bukan `accepted_with_flag`) = semua validasi lulus.

5. **Tes foto profil:**
   ```bash
   curl -I "http://absensi-gateway:8080/api/v1/media/photo/<person_id>"
   ```
   Harus: 200 dengan `Content-Type: image/*` atau `image/svg+xml`
   (kalau foto tidak ada, gateway serve avatar inisial — ini normal).
