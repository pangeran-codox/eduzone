<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — EduZone</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/areas/tenant.js'])
    <style>
        * { font-family: 'Plus Jakarta Sans', ui-sans-serif, system-ui; }
        .font-serif-brand { font-family: 'Fraunces', serif; }

        :root {
            --t-bg:      #F6F3EC;
            --t-dark:    #1B3A34;
            --t-dark-2:  #234840;
            --t-gold:    #C9A227;
            --t-text:    #1C1C1A;
            --t-muted:   #6B6B63;
            --t-border:  #D8D4C6;
            --t-green-bg: #EAF3DE;
            --t-green-tx: #3B6D11;
            --t-red-bg:  #FCEBEB;
            --t-red-tx:  #A32D2D;
            --t-amber-bg: #FBF0DC;
            --t-amber-tx: #92620A;
            --t-slate-bg: #EDEBE3;
            --t-slate-tx: #6B6B63;
        }

        body { background-color: var(--t-bg); color: var(--t-text); }

        .sidebar { background: var(--t-dark); width: 250px; flex-shrink: 0; }
        .nav-item {
            display: flex; align-items: center; gap: 10px; padding: 9px 14px;
            border-radius: 8px; font-size: 13.5px; font-weight: 500;
            color: #9FB8AE; transition: all 0.18s ease; text-decoration: none;
        }
        .nav-item:hover { color: #F6F3EC; background: rgba(255,255,255,0.06); }
        .nav-item.active { color: var(--t-dark); background: var(--t-gold); font-weight: 600; }
        .nav-item .icon { width: 17px; height: 17px; flex-shrink: 0; opacity: 0.85; }
        .nav-item.active .icon { opacity: 1; }
        .nav-section {
            font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;
            color: #5E7B72; padding: 0 14px; margin: 18px 0 6px;
        }

        .topbar { background: #fff; border-bottom: 1px solid var(--t-border); height: 56px; }
        .main-content { background: var(--t-bg); flex: 1; overflow-y: auto; }

        .t-card { background: #fff; border: 1px solid var(--t-border); border-radius: 14px; }
        .stat-card { background: #fff; border: 1px solid var(--t-border); border-radius: 14px; padding: 18px; }

        .badge {
            display: inline-flex; align-items: center; gap: 4px;
            font-size: 11px; font-weight: 600; padding: 2px 9px; border-radius: 999px;
        }
        .badge-green { background: var(--t-green-bg); color: var(--t-green-tx); }
        .badge-red   { background: var(--t-red-bg);   color: var(--t-red-tx); }
        .badge-amber { background: var(--t-amber-bg); color: var(--t-amber-tx); }
        .badge-slate { background: var(--t-slate-bg); color: var(--t-slate-tx); }
        .badge-gold  { background: rgba(201,162,39,0.15); color: #8A6D1B; }

        .t-table { width: 100%; border-collapse: collapse; }
        .t-table th {
            text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.05em; color: #8A8A80; padding: 10px 16px;
            border-bottom: 1px solid var(--t-border);
        }
        .t-table td {
            padding: 12px 16px; font-size: 13.5px; color: #3A3A34;
            border-bottom: 1px solid #EFEBE0;
        }
        .t-table tr:last-child td { border-bottom: none; }
        .t-table tr:hover td { background: #FBFAF6; }

        #sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 40; }
        #sidebar-overlay.active { display: block; }
        .sidebar { z-index: 50; }
        @media (max-width: 1023px) {
            .sidebar { position: fixed; top: 0; left: 0; bottom: 0; transform: translateX(-100%); transition: transform 0.25s ease; }
            .sidebar.open { transform: translateX(0); }
        }

        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(27,58,52,0.2); border-radius: 999px; }
    </style>
    @stack('styles')
</head>
<body class="h-full flex overflow-hidden">

<div id="sidebar-overlay" onclick="closeSidebar()"></div>

<aside id="sidebar" class="sidebar flex flex-col h-full overflow-y-auto">
    <div class="px-5 py-5 border-b" style="border-color: rgba(255,255,255,0.08);">
        <div class="font-serif-brand text-lg" style="color:#F6F3EC;">EduZone</div>
        <div class="text-xs mt-0.5" style="color:#7C9A8E;">{{ auth()->user()->school->name ?? 'Sekolah' }}</div>
    </div>

    <nav class="flex-1 px-3 py-4">
        <p class="nav-section">Menu</p>

        {{--
            Dashboard nav item ditentukan dari role user yang login, BUKAN
            hardcode ke route tertentu — sebelumnya semua role diarahkan ke
            guru.dashboard (bug, nyebabin 403 buat role selain guru/wali
            kelas). Dashboard utama role ini selalu tampil duluan (walau
            route lain di sekolah ini belum semua ada); route lain baru
            muncul kalau Route::has() true, biar aman dipakai semua role.
        --}}
        @php
            $role = auth()->user()->role ?? null;

            $roleDashboardRoute = match ($role) {
                'kepsek'              => 'kepsek.dashboard',
                'kurikulum'           => 'kurikulum.dashboard',
                'tu'                  => 'tu.dashboard',
                'guru_mapel',
                'wali_kelas'          => 'guru.dashboard',
                'kesiswaan'           => 'kesiswaan.dashboard',
                'bk'                  => 'bk.dashboard',
                'toolman'             => 'toolman.dashboard',
                'siswa'               => 'siswa.dashboard',
                default               => null,
            };

            $roleLabel = match ($role) {
                'kepsek'      => 'Kepala Sekolah',
                'kurikulum'   => 'Kurikulum',
                'tu'          => 'Tata Usaha',
                'guru_mapel'  => 'Guru Mapel',
                'wali_kelas'  => 'Wali Kelas',
                'kesiswaan'   => 'Kesiswaan',
                'bk'          => 'BK',
                'toolman'     => 'Toolman',
                'siswa'       => 'Siswa',
                default       => 'Pengguna',
            };
        @endphp

        @if (Route::has('absen-hp.show'))
        <a href="{{ route('absen-hp.show') }}" class="nav-item {{ request()->routeIs('absen-hp.show') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.5-7.5 11.25-7.5 11.25S4.5 18 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            Absen HP
        </a>
        @endif

        @if ($roleDashboardRoute && Route::has($roleDashboardRoute))
        <a href="{{ route($roleDashboardRoute) }}" class="nav-item {{ request()->routeIs($roleDashboardRoute) ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"/>
            </svg>
            Dashboard
        </a>
        @endif

        @if ($role === 'kurikulum' && Route::has('kurikulum.pengganti.index'))
        <a href="{{ route('kurikulum.pengganti.index') }}" class="nav-item {{ request()->routeIs('kurikulum.pengganti.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5"/>
            </svg>
            Guru Pengganti
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.siswa.index'))
        <a href="{{ route('tu.siswa.index') }}" class="nav-item {{ request()->routeIs('tu.siswa.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/>
            </svg>
            Data Siswa
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.guru.index'))
        <a href="{{ route('tu.guru.index') }}" class="nav-item {{ request()->routeIs('tu.guru.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.697 50.697 0 0112 13.489a50.702 50.702 0 017.74-3.342M6.75 15a.75.75 0 100-1.5.75.75 0 000 1.5zm0 0v-3.675A55.378 55.378 0 0112 8.443m-7.007 11.55A5.981 5.981 0 006.75 15.75v-1.5"/>
            </svg>
            Data Guru
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.staff.index'))
        <a href="{{ route('tu.staff.index') }}" class="nav-item {{ request()->routeIs('tu.staff.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            Data Staff
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.impor.index'))
        <a href="{{ route('tu.impor.index') }}" class="nav-item {{ request()->routeIs('tu.impor.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/>
            </svg>
            Impor Data
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.absensi.index'))
        <a href="{{ route('tu.absensi.index') }}" class="nav-item {{ request()->routeIs('tu.absensi.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"/>
            </svg>
            Dashboard Absensi
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.kredensial.index'))
        <a href="{{ route('tu.kredensial.index') }}" class="nav-item {{ request()->routeIs('tu.kredensial.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 4.5h16.5M3.75 9h16.5M3.75 13.5h16.5m-16.5 4.5h16.5"/>
            </svg>
            Kredensial QR
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.absensi.manual.index'))
        <a href="{{ route('tu.absensi.manual.index') }}" class="nav-item {{ request()->routeIs('tu.absensi.manual.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
            </svg>
            Input Manual Absensi
        </a>
        @endif

        @if ($role === 'wali_kelas' && Route::has('wali_kelas.absensi.dashboard'))
        <a href="{{ route('wali_kelas.absensi.dashboard') }}" class="nav-item {{ request()->routeIs('wali_kelas.absensi.dashboard') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"/>
            </svg>
            Absensi Kelas
        </a>
        @endif

        @if ($role === 'kepsek' && Route::has('kepsek.absensi.index'))
        <a href="{{ route('kepsek.absensi.index') }}" class="nav-item {{ request()->routeIs('kepsek.absensi.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"/>
            </svg>
            Monitoring Absensi
        </a>
        @endif

        @if (in_array($role, ['kepsek', 'tu']) && Route::has('absensi.rekap.index'))
        <a href="{{ route('absensi.rekap.index') }}" class="nav-item {{ request()->routeIs('absensi.rekap.index') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"/>
            </svg>
            Rekap Absensi
        </a>
        @endif

        @if (in_array($role, ['kepsek', 'tu']) && Route::has('absensi.devices.index'))
        <a href="{{ route('absensi.devices.index') }}" class="nav-item {{ request()->routeIs('absensi.devices.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 12V5.25" />
            </svg>
            Device Absensi
        </a>
        @endif

        @if ($role === 'tu' && Route::has('tu.laporan.index'))
        <a href="{{ route('tu.laporan.index') }}" class="nav-item {{ request()->routeIs('tu.laporan.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z"/>
            </svg>
            Laporan Absensi
        </a>
        @endif

        @if ($role === 'guru_mapel' && Route::has('guru_mapel.absensi.index'))
        <a href="{{ route('guru_mapel.absensi.index') }}" class="nav-item {{ request()->routeIs('guru_mapel.absensi.*') ? 'active' : '' }}">
            <svg class="icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"/>
            </svg>
            Absensi Mengajar
        </a>
        @endif

        {{-- Slot buat nav item tambahan spesifik per-role, tanpa harus edit layout ini lagi --}}
        @stack('nav-items')
    </nav>

    <div class="px-3 py-4 border-t" style="border-color: rgba(255,255,255,0.08);">
        <div class="flex items-center gap-3 px-3 py-2.5 rounded-xl" style="background: rgba(255,255,255,0.06);">
            <div class="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold flex-shrink-0"
                 style="background: var(--t-gold); color: var(--t-dark);">
                {{ strtoupper(substr(auth()->user()->username ?? auth()->user()->email ?? 'U', 0, 2)) }}
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-xs font-semibold truncate" style="color:#F6F3EC;">{{ auth()->user()->username ?? auth()->user()->email }}</p>
                <p class="text-xs truncate" style="color:#9FB8AE;">{{ $roleLabel }}</p>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="p-1.5 rounded-lg" style="color:#9FB8AE;" title="Keluar">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9"/>
                    </svg>
                </button>
            </form>
        </div>
    </div>
</aside>

<div class="flex flex-col flex-1 overflow-hidden">
    <header class="topbar flex items-center justify-between px-6 flex-shrink-0">
        <div class="flex items-center gap-4">
            <button onclick="openSidebar()" class="lg:hidden p-1.5 rounded-lg" style="color:#6B6B63;">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/>
                </svg>
            </button>
            <span class="font-semibold text-sm" style="color: var(--t-dark);">@yield('page-title', 'Dashboard')</span>
        </div>
        <span class="hidden md:block text-xs" style="color:#8A8A80;">{{ now()->translatedFormat('l, d M Y') }}</span>
    </header>

    <main class="main-content">
        <div class="p-6">
            @yield('content')
        </div>
    </main>
</div>

<script>
function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebar-overlay').classList.add('active');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-overlay').classList.remove('active');
}
</script>

@stack('scripts')
</body>
</html>