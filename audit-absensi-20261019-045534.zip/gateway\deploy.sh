#!/usr/bin/env bash
# deploy.sh — deploy / update absensi-gateway di Docker Swarm.
# Versi image dibaca dari APP_VERSION di .env. Jalankan di node manager (tameng).
#
#   chmod +x deploy.sh
#   ./deploy.sh
#
# Rollback ke versi sebelumnya:
#   docker service rollback absensi-gateway_absensi-gateway
# lalu samakan APP_VERSION di .env dengan versi yang berjalan.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "ERROR: file .env tidak ditemukan di $(pwd)" >&2
  exit 1
fi

set -a
. ./.env
set +a

: "${APP_VERSION:?APP_VERSION belum diisi di .env}"
IMAGE="${IMAGE_REPO:-iswant/absensi-gateway}:${APP_VERSION}"

echo ">> Deploy ${IMAGE}"
docker stack deploy \
  --with-registry-auth \
  --resolve-image always \
  -c docker-compose.swarm.yml \
  absensi-gateway

echo ">> Status service"
docker service ls --filter name=absensi-gateway
echo ">> Pantau rollout: docker service ps absensi-gateway_absensi-gateway"
echo ">> Log: docker service logs -f absensi-gateway_absensi-gateway"
