<?php

use App\Http\Controllers\Superadmin\Auth\SuperadminLoginController;
use App\Http\Controllers\Superadmin\DashboardController;
use App\Http\Controllers\Superadmin\AbsensiHealthController;
use App\Http\Controllers\Superadmin\AbsensiRekapController;
use App\Http\Controllers\Superadmin\DeviceController;
use App\Http\Controllers\Superadmin\SchoolController;
use App\Http\Controllers\Superadmin\UserController;
use App\Http\Controllers\Superadmin\ActivityLogController;
use App\Http\Controllers\Superadmin\SubscriptionController;
use App\Http\Controllers\Superadmin\SchoolRegistrationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Superadmin Routes
| Prefix  : /superadmin  (didefinisikan di bootstrap/app.php)
| Name    : superadmin.  (didefinisikan di bootstrap/app.php)
| Semua route di sini TIDAK pakai tenant middleware
|--------------------------------------------------------------------------
*/

// ── Auth (guest) ───────────────────────────────────────────────────────
Route::middleware('guest')->group(function () {
    Route::get('/login',  [SuperadminLoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [SuperadminLoginController::class, 'login']);
});

// ── Protected (superadmin only) ────────────────────────────────────────
Route::middleware('superadmin')->group(function () {

    Route::post('/logout', [SuperadminLoginController::class, 'logout'])->name('logout');

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Schools management
    Route::prefix('schools')->name('schools.')->group(function () {
    Route::get('/', [SchoolController::class, 'index'])->name('index');
    Route::get('/create', [SchoolController::class, 'create'])->name('create');
    Route::post('/', [SchoolController::class, 'store'])->name('store');
    Route::get('/{school}/edit', [SchoolController::class, 'edit'])->name('edit');
    Route::put('/{school}', [SchoolController::class, 'update'])->name('update');
    Route::delete('/{school}', [SchoolController::class, 'destroy'])->name('destroy');
    });

    // School registrations management
    Route::get('registrations', [SchoolRegistrationController::class, 'index'])->name('registrations.index');
    Route::get('registrations/{registration}', [SchoolRegistrationController::class, 'show'])
        ->whereUuid('registration')->name('registrations.show');
    Route::post('registrations/{registration}/approve', [SchoolRegistrationController::class, 'approve'])
        ->whereUuid('registration')->name('registrations.approve');
    Route::post('registrations/{registration}/reject', [SchoolRegistrationController::class, 'reject'])
        ->whereUuid('registration')->name('registrations.reject');
    Route::post('registrations/{registration}/resend-password-setup', [SchoolRegistrationController::class, 'resendPasswordSetup'])
        ->whereUuid('registration')->name('registrations.resend-password-setup');

    // Users management
    Route::get('/users', [UserController::class, 'index'])->name('users.index');

    // Subscriptions
    Route::prefix('subscriptions')->name('subscriptions.')->group(function () {
    Route::get('/', [SubscriptionController::class, 'index'])->name('index');
    Route::get('/create', [SubscriptionController::class, 'create'])->name('create');
    Route::post('/', [SubscriptionController::class, 'store'])->name('store');
    Route::get('/{subscription}/edit', [SubscriptionController::class, 'edit'])->name('edit');
    Route::put('/{subscription}', [SubscriptionController::class, 'update'])->name('update');
    Route::delete('/{subscription}', [SubscriptionController::class, 'destroy'])->name('destroy');
});


    // Logs
    Route::get('/logs', [ActivityLogController::class, 'index'])->name('logs');

    // Absensi — health check gateway/DB/sync/device per sekolah
    Route::get('/absensi/health', [AbsensiHealthController::class, 'index'])
        ->name('absensi.health');

    Route::get('/absensi/health/status', [AbsensiHealthController::class, 'status'])
        ->name('absensi.health.status');
    Route::get('/absensi/rekap', [AbsensiRekapController::class, 'index'])
        ->name('absensi.rekap');
    Route::get('/absensi/rekap/status', [AbsensiRekapController::class, 'status'])
        ->name('absensi.rekap.status');

    Route::prefix('absensi/devices')->name('absensi.devices.')->group(function () {
    Route::get('/', [DeviceController::class, 'index'])->name('index');
    Route::get('/create', [DeviceController::class, 'create'])->name('create');
    Route::post('/', [DeviceController::class, 'store'])->name('store');
    Route::get('/{device}/edit', [DeviceController::class, 'edit'])->name('edit');
    Route::put('/{device}', [DeviceController::class, 'update'])->name('update');
    Route::delete('/{device}', [DeviceController::class, 'destroy'])->name('destroy');
    Route::post('/{device}/regenerate-key', [DeviceController::class, 'regenerateKey'])->name('regenerate-key');
});

});